
NREL 5MW Reference Turbine OpenFAST Model
=========================================

This directory contains the inputs for the NREL 5MW reference turbine.
More information on this turbine can be found in the
`2009 paper <https://www.nrel.gov/docs/fy09osti/38060.pdf>`_.
