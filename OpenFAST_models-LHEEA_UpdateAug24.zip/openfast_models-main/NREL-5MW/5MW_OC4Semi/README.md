## 5MW_OC4Semi_WSt_WavesWN

Reference papers:

- Robertson, A., Jonkman, J., Masciola, M., Song, H., Goupee, A., Coulling, A., and Luan, C. Definition of the Semisubmersible Floating System for Phase II of OC4. United States: N. p., 2014. Web. doi:10.2172/1155123. [Link](https://www.nrel.gov/docs/fy14osti/60601.pdf)