# OpenFAST Models

This folder gathers various input files retrieved from different sources, with the main turbine and platform models to use. It aims at being a single place source for both the turbine files and their documentation. Please not that they were not developped here and all credits goes to the sources mentionned. 

**All the files below were succesfully run with OpenFAST v.3.5.1**

# NREL-5MW 

This is the 5MW wind reference wind turbine published by NREL in 2009. It consists of a 126 meters wide rotor at a hub height of 90 meters. It has been used a lot for the development of OpenFAST, thus many models are available in the r-test folder of the [OpenFAST GitHub](https://github.com/OpenFAST)

The models were developped as part of the OC3 and OC4 projects. 

Some of them are : 
* 5MW baseline 
* ITI barge 
* OC3 monopile 
* OC3 spar 
* OC3 tripod 
* OC4 jacket
* OC4 semi  

For the reference papers see : 

* Jonkman, J., and Musial, W. **Offshore Code Comparison Collaboration (OC3) for IEA Wind Task 23 Offshore Wind Technology and Deployment.** 2010.
* Popko et al. **Offshore code comparison collaboration continuation (OC4), phase 1-results of coupled simulations of an offshore wind turbine with jacket support structure.** In ISOPE International Ocean and Polar Engineering Conference. 2012.

# IEA-10MW 

The IEA-10MW has been released in 2018, based on previous work from the DTU-10MW. Its main characteristics are a 198 meters wide rotor located at a hub height of 119 meters. 

Not many model of platform have been developped for this one, so the only available one that we know of is a 30 meters deep monopile structure. 

The reference paper for this turbine is : 

* Bortolotti et al. **IEA Wind Task 37 on Systems Engineering in Wind Energy
WP2.1**
 2019. 

# IEA-15MW 

This 15 MW turbine has been published in 2020. It consists of a 240m wide rotor at a hub height of 150m. Additionnaly this is a direct drive turbine with no multiplicator. The available models are : 
* base turbine 
* monopile structure (30 meters depth)
* semi-submersible platform (200 meters depth, catenary mooring)

Source files come from [IEA GitHub page](https://github.com/IEAWindTask37/IEA-15-240-RWT)
(last consulted 15th of April 2024)

The reference documents are : 
* For the turbine : Gaertner et al. 2020. **Definition of the IEA 15-Megawatt Offshore Reference
Wind Turbine**. Golden, CO: National Renewable Energy Laboratory.
* For the floater : Allen et al.  **Definition of the UMaine VolturnUS-S Reference Platform Developed for the IEA Wind 15-Megawatt Offshore Reference Wind Turbine.** Golden, CO: National Renewable Energy Laboratory.

# IEA-22MW 

The IEA 22MW is a model turbine that was developped in 2024 to provide a model for bigger scale turbines. Its rotor is 284 meters wide and the hub is located at a height of 170m. Its rated wind speed is 11 m/s. 

The available OpenFAST files for this model are: 
* baseline turbine 
* monopile, with 34 m depth 
* semi-submersible platform which is a scaled model of the Volturn-US model used for the 15MW turbine. 

Source files come from the IEA [GitHub Page](https://github.com/IEAWindTask37/IEA-22-280-RWT/tree/main/OpenFAST)
(last consulted 29th of April 2024)

The reference document for this turbine is : 
* [Zahle, et al. **Definition of the IEA Wind 22-Megawatt Offshore Reference Wind Turbine.** Technical University of Denmark. 2024](https://doi.org/10.11581/DTU.00000317)



