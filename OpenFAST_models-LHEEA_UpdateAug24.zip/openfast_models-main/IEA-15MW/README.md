# IEA15MW

This folder holds example files for running simulations on the IEA reference 15 MW wind turbine. 
To run it the user needs OpenFAST  v3.5.1 installed along with Turbsim v2.0 

To run the python scripts the user must install the [openfast-toolbox](https://github.com/OpenFAST/openfast_toolbox) 

## Contents

setUpSimulation.py shows how to set up and run a simulation with an OpenFAST temmplate and a dictionnary of parameters to set for the simulation 

# OpenFAST 
The OpenFAST input files are sourced from [IEA GitHub](https://github.com/IEAWindTask37/IEA-15-240-RWT) (if not mentionned otherwise) 

