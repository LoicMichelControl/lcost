#Example to set a simple simulation using the python toolbox 
import os 
from openfast_toolbox.io.fast_input_file import FASTInputFile
import openfast_toolbox.case_generation.case_gen as case_gen
import openfast_toolbox.case_generation.runner as runner

runFast = False 
refDir = "IEA-15-240-RWT-UMaineSemi"
workDir = "01_RegWave_SteadWind"
mainFile = "IEA-15-240-RWT-UMaineSemi.fst"
#Path to openfast 3.5.1
OFexe = r"C:\Users\mandre\Documents\FAST\openfast_3_51\openfast_x64.exe"

# Get current directory so this script can be called from any location
scriptDir=os.path.dirname(__file__)

#Setting the list of parameters for the new simulation 
p = dict() 
p["__name__"]="Case01"
p["TMax"]=100 
p["HydroFile|WaveMod"]=1
p["HydroFile|WaveHs"] = 7.5
p["HydroFile|WaveTp"] = 10
p["HydroFile|WaveTMax"] = p["TMax"]
p["InflowFile|WindType"] = 1 
p["InflowFile|HWindSpeed"] = 12
PARAMS = [p]

#Using the new parameter list and the template to generate new simulation input files  
case_gen.templateReplace(PARAMS, refDir, outputDir=workDir, removeRefSubFiles=True, main_file=mainFile, oneSimPerDir=False)

#Launch the simulation 
if runFast : 
    fastFiles = ['OpenFAST/01_RegWave_SteadWind\\Case01.fst']
    runner.run_fastfiles(fastFiles, fastExe=OFexe, parallel=True, showOutputs=False, nCores=4)


